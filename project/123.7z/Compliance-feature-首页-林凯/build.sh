#!/usr/bin/env bash

set -e
set -x

# update the yum
createrepo /opt/local_yum
yum clean all

# env
cd /build && source ./devenvrc

# setup the egg
cd /build/cosd_compliance
target=$APPNAME-$APPVERION.tar.gz
python3 setup.py sdist
cp dist/$target /opt/local_python_dist

# the depened packages
rpm_install_packages=()

rpm_install_packages+=("systemd")
rpm_install_packages+=("vim-minimal")
rpm_install_packages+=("python3")
rpm_install_packages+=("libxslt")
rpm_install_packages+=("libxml2")

python_install_packages=()

python_install_packages+=("Cython-0.29.19.tar.gz")
python_install_packages+=("uvloop-0.14.0.tar.gz")
python_install_packages+=("httptools-0.1.1.tar.gz")
python_install_packages+=("websockets-8.1.tar.gz")
python_install_packages+=("h11-0.9.0.tar.gz")
python_install_packages+=("click-7.1.2.tar.gz")
python_install_packages+=("uvicorn-0.11.5.tar.gz")
python_install_packages+=("dataclasses-0.7.tar.gz")
python_install_packages+=("pydantic-1.5.1.tar.gz")
python_install_packages+=("starlette-0.13.2.tar.gz")
python_install_packages+=("fastapi-0.55.1.tar.gz")
python_install_packages+=("SQLAlchemy-1.3.17.tar.gz")
python_install_packages+=("aiofiles-0.5.0.tar.gz")
python_install_packages+=("docx2python-1.24.tar.gz")
python_install_packages+=("certifi-2020.6.20.tar.gz")
python_install_packages+=("chardet-3.0.4.tar.gz")
python_install_packages+=("idna-2.9.tar.gz")
python_install_packages+=("urllib3-1.25.9.tar.gz")
python_install_packages+=("requests-2.24.0.tar.gz")
python_install_packages+=("async_exit_stack-1.0.1.tar.gz")
python_install_packages+=("async_generator-1.10.tar.gz")
python_install_packages+=("lxml-4.5.1.tar.gz")
python_install_packages+=("python-docx-1-0.0.2.tar.gz")
python_install_packages+=("$target")

for i in ${rpm_install_packages[*]}; do
	install_packages_cmd="$install_packages_cmd -p $i"
done

python_install_packages_cmd=""

for i in ${python_install_packages[*]}; do
	python_install_packages_cmd="$python_install_packages_cmd -e $i"
done

DATE=$(date "+%Y%m%d%H%M%S")

cd /build && sh mkimage.sh $install_packages_cmd $python_install_packages_cmd "$APPNAME-$APPVERION-$DATE" 

# upload the images
cd /root

filename="$APPNAME-$APPVERION-$DATE.tar.xz" 

ls ${filename} -alh

#ftp 服务器用户名和密码 ip
user=develop
passwd=develop
serverip="200.200.0.3" 

md5sumfile="${filename}.md5sum"
md5sum ${filename} > ${md5sumfile}

echo "upload ${filename} ${md5sumfile} to server"

ftp -n <<- EOF
open ${serverip}
user ${user} ${passwd}
cd COSD/Compliance/${APPVERION}
binary
put ${filename} 
put ${md5sumfile}
exit
EOF

echo "finished"
