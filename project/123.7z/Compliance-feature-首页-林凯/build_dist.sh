#!/usr/bin/env bash

set -e
set -x

cd /build

# env
source ./devenvrc

# setup the egg
cd cosd_compliance
filename=$APPNAME-$APPVERION.tar.gz
python3 setup.py sdist

cd dist

ls ${filename} -alh

#ftp 服务器用户名和密码 ip
user=develop
passwd=develop
serverip="200.200.0.3" 

md5sumfile="${filename}.md5sum"
md5sum ${filename} > ${md5sumfile}

echo "upload ${filename} ${md5sumfile} to server"

ftp -n <<- EOF
open ${serverip}
user ${user} ${passwd}
cd COSD/Compliance/${APPVERION}
binary
put ${filename} 
put ${md5sumfile}
exit
EOF

echo "finished"
