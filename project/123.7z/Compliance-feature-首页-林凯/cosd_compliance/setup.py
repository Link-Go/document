#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import re

from setuptools import setup


def get_version(package):
    """
    Return package version as listed in `__version__` in `init.py`.
    """
    path = os.path.join(package, "__init__.py")
    init_py = open(path, "r", encoding="utf8").read()
    return re.search("__version__ = ['\"]([^'\"]+)['\"]", init_py).group(1)


def get_packages(package):
    """
    Return root package and all sub-packages.
    """
    return [
        dirpath
        for dirpath, dirnames, filenames in os.walk(package)
        if os.path.exists(os.path.join(dirpath, "__init__.py"))
    ]


setup(name="cosd_compliance",
      version=get_version("cosd_compliance"),
      description="compliance center",
      long_description="compliance center",
      include_package_data=True,
      author="cosd",
      packages=get_packages("cosd_compliance"),
      zip_safe=False,
      install_requires=[
          'fastapi >= 0.55.1',
          'SQLAlchemy >= 1.3.17',
          'aiofiles >= 0.5.0'
      ]
      )
