# built_in
import json
import logging
import asyncio
from fastapi import status
from urllib.parse import urlencode
from urllib.request import urlopen
from urllib.error import HTTPError
from typing import List, Set, Tuple, Dict
from starlette.websockets import WebSocketState
from websockets.exceptions import ConnectionClosedOK
from concurrent.futures._base import TimeoutError

# customized
from cosd_compliance.cfg import ws_cfg
from cosd_compliance.models import ws_models

# global variables
LOCK = asyncio.Lock()

# init
# TODO: add log
logger = logging.getLogger(__name__)


def access_auth(token: str) -> bool:
    '''
    access auth of device
    return False when crash
    '''
    params = urlencode({'token_auth': token})
    auth_url = f'{ws_cfg.AUTH_URL}?{params}'
    try:
        with urlopen(auth_url) as f:
            if f.status == status.HTTP_200_OK:
                return True
            else:
                return False
    except Exception as e:
        print(f'{e}')
        return False


async def send_and_recv(device_id: str, send_data: str, only_text=True):
    '''
    send json str to ws_client
    and receive data from ws_client
    if data is json str, decode json str and return
    if data is bytes, just return
    rm closed CONNECTIONS
    do not catch exception, just let it crash
    '''
    websocket = ws_cfg.CONNECTIONS[device_id]

    # send
    try:
        await websocket.send_text(send_data)
    except ConnectionClosedOK as e:
        print(f'WS: {device_id} CONNECTIONS closed: {e}')
        websocket.client_state = WebSocketState.DISCONNECTED
        if device_id in ws_cfg.CONNECTIONS: ws_cfg.CONNECTIONS.pop(device_id)
        raise e

    # recv
    # TODO: add requestID(uuid) to make sure
    assert websocket.application_state == WebSocketState.CONNECTED
    message = await websocket.receive()
    websocket._raise_on_disconnect(message)

    # json string or bytes
    if only_text:
        return json.loads(message.get('text'))

    bytes_data = message.get('bytes')
    return bytes_data if bytes_data else json.loads(message.get('text'))


async def send_and_recv_with_timeout(
        device_id: str, send_data: str, only_text: bool = True):
    '''
    add timeout to async func: send_and_recv
    '''
    recv_data = await asyncio.wait_for(send_and_recv(device_id, send_data, only_text), timeout=ws_cfg.WS_TIMEOUT)
    return recv_data


async def create_task(
    task_id: str, level: int, address: Set[str],
    devices: Set[str], evals: Set[str] = set()
) -> Tuple[List[ws_models.DeviceExeResult]]:
    '''
    Used to create task
    this func do not check validation of params
    check params by yourself before call the func

    :param task_id: task uuid, littler than 512
    :param level: compliance level, enum: 2, 3
    :param address: set of system IP, the ip(IPV4/dotted-decimal) is string
    :param devices: set of device ID, the ID is string
    :param evals: set of evalute item, default is empty set that means all items

    Returns two list of DeviceExeResult: (successful, failed)

    Usage:
      successful, failed = await create_task(task_id, level, address, devices, evals)
    '''
    successful, failed = [], []

    # create ws message
    ws_msg = ws_models.WsMsg(
        obj=ws_models.WsObj.task,
        action=ws_models.WsAction.create,
        data=ws_models.TaskForCreate(
            task_id=task_id,
            level=level,
            address=list(address),
            evals=list(evals)
        ).dict()
    ).dict()
    ws_josn_str = json.dumps(ws_msg)

    # generate executable item list
    exe_items, exe_records = [], []
    for device_id in devices:
        # check CONNECTIONS of device is alive
        if device_id not in ws_cfg.CONNECTIONS:
            failed.append(ws_models.DeviceExeResult(
                device_id=device_id,
                message=ws_models.DeviceExeMsg.offline.value
            ))
            continue
        exe_records.append(device_id)
        exe_items.append(send_and_recv_with_timeout(device_id, ws_josn_str))

    # execute, send ws msg and recv result
    items = await asyncio.gather(*exe_items, return_exceptions=True)

    # handle exe items
    for i, item in enumerate(items):
        #
        device_exe_result = ws_models.DeviceExeResult(device_id=exe_records[i])
        # ws closed
        if isinstance(item, ConnectionClosedOK):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.offline.value
            failed.append(device_exe_result)
            continue
        # timeout
        if isinstance(item, TimeoutError):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.timeout.value
            failed.append(device_exe_result)
            continue
        # json decode error
        if isinstance(item, json.decoder.JSONDecodeError):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.json_decode_error.value
            failed.append(device_exe_result)
            continue
        # other
        if isinstance(item, Exception):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.internal_error.value
            failed.append(device_exe_result)
            continue

        # get message from recv data
        device_exe_result.message = item.get('message')

        # device reponse error
        if not item.get('successful'):
            failed.append(device_exe_result)
            continue

        # success
        device_exe_result.successful = True
        successful.append(device_exe_result)

    print(f'S:\n {successful}\nF:\n{failed}')
    return successful, failed


async def query_task(task_id: str, devices: Set[str]) -> Tuple[List[ws_models.DeviceQueryTaskResult]]:
    '''
    Used to query task
    this func do not check validation of params
    check params by yourself before call the func

    :param task_id: task uuid, littler than 512
    :param devices: set of device ID, the ID is string

    Returns two list of DeviceQueryTaskResult: (successful, failed)

    Usage:
      successful, failed = await query_task(task_id, devices)
    '''
    successful, failed = [], []

    # create ws message
    ws_msg = ws_models.WsMsg(
        obj=ws_models.WsObj.task,
        action=ws_models.WsAction.query,
        data=ws_models.TaskForQuery(task_id=task_id).dict()
    ).dict()
    ws_josn_str = json.dumps(ws_msg)

    # generate executable item list
    exe_items, exe_records = [], []
    for device_id in devices:
        # check CONNECTIONS of device is alive
        if device_id not in ws_cfg.CONNECTIONS:
            failed.append(ws_models.DeviceQueryTaskResult(
                device_id=device_id,
                message=ws_models.DeviceExeMsg.offline.value
            ))
            continue
        exe_records.append(device_id)
        exe_items.append(send_and_recv_with_timeout(device_id, ws_josn_str))

    # execute, send ws msg and recv result
    items = await asyncio.gather(*exe_items, return_exceptions=True)

    '''
    done: <Task finished coro=<send_and_recv() done, defined at .\route.py:27> result='create success'>
    done: <Task finished coro=<send_and_recv() done, defined at .\route.py:27> exception=ConnectionClosedOK('code = 1000 (OK), no reason',)>
    pending: <Task pending coro=<send_and_recv() running at .\route.py:33> wait_for=<Future pending cb=[<TaskWakeupMethWrapper object at 0x0000000003DB9B88>()]>>
    '''
    # handle exe items
    for i, item in enumerate(items):
        device_query_task_result = ws_models.DeviceQueryTaskResult(
            device_id=exe_records[i])
        # ws CONNECTIONS closed
        if isinstance(item, ConnectionClosedOK):
            print(item)
            device_query_task_result.message = ws_models.DeviceExeMsg.offline.value
            failed.append(device_query_task_result)
            continue
        # timeout
        if isinstance(item, TimeoutError):
            print(item)
            device_query_task_result.message = ws_models.DeviceExeMsg.timeout.value
            failed.append(device_query_task_result)
            continue
        # json decode error
        if isinstance(item, json.decoder.JSONDecodeError):
            print(item)
            device_query_task_result.message = ws_models.DeviceExeMsg.json_decode_error.value
            failed.append(device_query_task_result)
            continue
        # other
        if isinstance(item, Exception):
            print(item)
            device_query_task_result.message = ws_models.DeviceExeMsg.internal_error.value
            failed.append(device_query_task_result)
            continue

       # get message from recv data
        device_query_task_result.message = item.get('message')

        # device response error
        if not item.get('successful'):
            failed.append(device_query_task_result)
            continue

        # convert data into object
        data = item.get('data', {})
        json_results = data.get('results', [])
        obj_results = []
        for device_task_result in json_results:
            json_records = device_task_result.get('records', [])
            obj_records = []
            for record in json_records:
                json_items = record.get('items', [])
                obj_items = [ws_models.DeviceTaskItem(
                    **item) for item in json_items]
                record['items'] = obj_items
                obj_records.append(ws_models.DeviceTaskRecord(**record))
            device_task_result['records'] = obj_records
            obj_results.append(
                ws_models.DeviceTaskResult(**device_task_result))
        data['results'] = obj_results
        device_detect_result = ws_models.DeviceDetectResult(**data)

        device_query_task_result.successful = True
        device_query_task_result.detect_result = device_detect_result
        successful.append(device_query_task_result)

    print(f'S:\n {successful}\nF:\n{failed}')
    return successful, failed


async def delete_task(task_id: str, devices: Set[str]) -> Tuple[List[ws_models.DeviceExeResult]]:
    '''
    Used to dekete task
    this func do not check validation of params
    check params by yourself before call the func

    :param task_id: task uuid, littler than 512
    :param devices: set of device ID, the ID is string

    Returns two list of DeviceExeResult: (successful, failed)

    Usage:
      successful, failed = await delete_task(task_id, devices)
    '''
    successful, failed = [], []

    # create ws message
    ws_msg = ws_models.WsMsg(
        obj=ws_models.WsObj.task,
        action=ws_models.WsAction.delete,
        data=ws_models.TaskForDelete(task_id=task_id).dict()
    ).dict()
    ws_josn_str = json.dumps(ws_msg)

    # generate executable item list
    exe_items, exe_records = [], []
    for device_id in devices:
        # check CONNECTIONS of device is alive
        if device_id not in ws_cfg.CONNECTIONS:
            failed.append(ws_models.DeviceExeResult(
                device_id=device_id,
                message=ws_models.DeviceExeMsg.offline.value
            ))
            continue
        exe_records.append(device_id)
        exe_items.append(send_and_recv_with_timeout(device_id, ws_josn_str))

    # execute, send ws msg and recv result
    items = await asyncio.gather(*exe_items, return_exceptions=True)

    # handle exe items
    for i, item in enumerate(items):
        #
        device_exe_result = ws_models.DeviceExeResult(device_id=exe_records[i])
        # ws closed
        if isinstance(item, ConnectionClosedOK):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.offline.value
            failed.append(device_exe_result)
            continue
        # timeout
        if isinstance(item, TimeoutError):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.timeout.value
            failed.append(device_exe_result)
            continue
        # json decode error
        if isinstance(item, json.decoder.JSONDecodeError):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.json_decode_error.value
            failed.append(device_exe_result)
            continue
        # other
        if isinstance(item, Exception):
            print(item)
            device_exe_result.message = ws_models.DeviceExeMsg.internal_error.value
            failed.append(device_exe_result)
            continue

        # get message from recv data
        device_exe_result.message = item.get('message')

        # device reponse error
        if not item.get('successful'):
            failed.append(device_exe_result)
            continue

        # success
        device_exe_result.successful = True
        successful.append(device_exe_result)

    print(f'S:\n {successful}\nF:\n{failed}')
    return successful, failed


async def query_setting(device_id: str, eval_id: str, item_id: int) -> ws_models.DeviceQuerySettingResult:
    '''
    Used to query setting
    this func do not check validation of params
    check params by yourself before call the func

    :param device_id: device ID, the ID is string
    :param eval_id: eval ID, littler than 64
    :param item_id: item ID, int

    Usage:
      query_result = await query_setting(device_id, eval_id, item_id)
    '''
    result = ws_models.DeviceQuerySettingResult(device_id=device_id)

    # create ws message
    ws_msg = ws_models.WsMsg(
        obj=ws_models.WsObj.setting,
        action=ws_models.WsAction.query,
        data=ws_models.SettingForQuery(eval_id=eval_id, item_id=item_id).dict()
    ).dict()
    ws_josn_str = json.dumps(ws_msg)

    # check CONNECTIONS of device is alive
    if device_id not in ws_cfg.CONNECTIONS:
        result.message = ws_models.DeviceExeMsg.offline.value
        return result

    # send and recv
    # recv data is json or bytes
    try:
        recv_data = await send_and_recv_with_timeout(device_id, ws_josn_str, only_text=False)
        if isinstance(recv_data, bytes):
            result.successful = True
            result.message = ws_models.DeviceExeMsg.success.value
            result.bytes_data = recv_data
        else:
            result.message = recv_data.get('message')
    except ConnectionClosedOK as e:
        print(e)
        result.message = ws_models.DeviceExeMsg.offline.value
    except TimeoutError as e:
        print(e)
        result.message = ws_models.DeviceExeMsg.timeout.value
    except json.decoder.JSONDecodeError as e:
        print(e)
        result.message = ws_models.DeviceExeMsg.json_decode_error.value
    except Exception as e:
        print(e)
        result.message = ws_models.DeviceExeMsg.internal_error.value

    finally:
        return result

