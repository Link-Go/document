import re
import base64
import os
import requests
import asyncio

from datetime import datetime
from typing import List, Union, Tuple
from docx import Document
from docx2python import docx2python
from docx.shared import Pt, Inches
from docx.oxml.ns import qn
from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import and_

from cosd_compliance import schemas, models
from cosd_compliance.cfg import constant, preset_file
from cosd_compliance.utils.ws_utils import query_setting
from cosd_compliance.path.path import SipURL
from cosd_compliance.schemas import enums
from cosd_compliance.path import path


async def list_devices_systems(token: str):
    return await asyncio.gather(
        requests_list(SipURL.list_systems, token),
        requests_list(SipURL.list_devices, token)
    )


async def requests_list(
    url: str, token: str
) -> Union[schemas.SystemList, List[schemas.DeviceList]]:
    """获取系统/设备列表"""
    url = f"{url}/?token={token}"
    try:
        r = requests.get(url, verify=False)
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=408, detail="Request Time-out")

    if r.status_code != 200:
        raise HTTPException(status_code=r.status_code,
                            detail=r.json().get("message", None))
    return r.json()


async def cfg_guide(device: str, device_id: str, item_eval: str) -> str:
    """获取配置指引"""
    file_path = path.cfg_guide_path + "/" + f"{device}.docx"
    # 判断文件是否存在
    if not os.path.exists(file_path):
        res = await query_setting(device_id, item_eval, 123)
        print(res)
        if res.successful is False:
            raise HTTPException(status_code=400, detail="获取配置文件失败")

        with open(file_path, "wb") as f:
            f.write(res.bytes_data)

    try:
        cfg_all = docx2python(file_path)
    except FileNotFoundError:
        raise HTTPException(status_code=400, detail="配置指引文件丢失，请重新点击获取")

    cfg = ""
    start = False
    for item in cfg_all.body[0][0][0]:
        new_item = item.strip()
        if new_item == "":
            continue
        if new_item.startswith("#"):
            continue
        if start:
            if not re.match(r"[0-9A-Z]{5}-?\d+", new_item):
                if new_item.startswith("----media/"):
                    imagesname = new_item.strip("-").split("/")[1]
                    image = (base64.b64encode(
                        cfg_all.images[imagesname])).decode()
                    cfg += f"<img src=\"data:image/png;base64,{image}\" />"
                else:
                    cfg += f"{new_item} <br />"
            else:
                break
        if new_item == item_eval:
            cfg += f"{new_item} <br />"
            start = True
    return cfg


async def download_path(kind: str, cover_data: List[str],
                        content_data: List[List[str]]) -> Tuple[str, str]:
    """生成docx文档并存在本地"""
    # 获取模板
    if kind == "global":
        template_path = path.global_template_path
        docx_path = path.global_docx_path
        document = Document(template_path)
    else:
        template_path = path.artificial_template_path
        docx_path = path.artificial_docx_path
        document = Document(template_path)
    # 指定字体格式，大小
    style = document.styles['Normal']
    style.font.name = "微软雅黑"
    style._element.rPr.rFonts.set(qn('w:eastAsia'), u"微软雅黑")
    style.font.size = Pt(10)

    # 封面表格，内容表格
    table_cover, table_content = document.tables[0], document.tables[1]

    # 更新到封面表格
    for i, row in enumerate(table_cover.rows[:]):
        row.cells[1].text = cover_data[i]

    # 删除模板中示例数据
    for _, row in enumerate(table_content.rows[1:]):
        row._element.getparent().remove(row._element)

    # 更新到内容表格
    for i in range(len(content_data)):
        row_cells = table_content.add_row().cells
        for j, cell in enumerate(row_cells):
            # 判断是否为高风险项
            if j != 1:
                content = content_data[i][j]
                cell.text = content
            else:
                content, high_risk = content_data[i][j][0], content_data[i][j][1]
                cell.text = content
                if high_risk:
                    run = cell.add_paragraph().add_run()
                    run.add_picture(path.hish_risk, width=Inches(0.6))

            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.line_spacing = Pt(18)

    if not os.path.exists(docx_path):
        os.mkdir(docx_path)

    # 文件名以 人工核查指引 + 时间 命名
    time_format = datetime.now().strftime("%Y%m%d%H%M%S")
    if kind == "global":
        file_name = "全局分析指引" + time_format + r".docx"
        file_path = path.global_docx_path + "/" + file_name
    else:
        file_name = "人工核查指引" + time_format + r".docx"
        file_path = path.artificial_docx_path + "/" + file_name
    document.save(file_path)

    return (file_name, file_path)


async def deal_cover_data(evaluate_id: int, db: Session) -> List[str]:
    """获取docx封面数据"""
    record = db.query(models.Evaluations).get(evaluate_id)
    if not record:
        raise HTTPException(status_code=400, detail="bad request")

    # 将等级转化为中文
    safety_level = constant.SAFETY_LEVEL_EXCHANGE[record.level]
    datetime = record.datetime.strftime("%Y-%m-%d %H:%M")

    # 封面表格数据 [业务系统名称，安全等级，测评时间]
    return [record.name, f"第{safety_level}级", datetime]


async def deal_content_data(
        evaluate_id: int,
        kind: enums.UnconformKind,
        db: Session):
    """获取docx内容数据"""
    items_record = db.query(models.Items).\
        filter(and_(models.Items.kind == kind,
                    models.Items.pid == evaluate_id)).all()

    # global [控制点， (安全要求, high_risk), 核查指引, 符合说明, 符合状态]
    # artificial [控制点， (安全要求, high_risk), 相关设备, 核查指引, 符合说明, 符合状态]
    content_data = []
    for item_record in items_record:
        _eval = preset_file.fixed_text[item_record.eval][0]
        if kind == "artificial":
            _eval = preset_file.safety_kind[item_record.eval[0]] + _eval

        # 判断是否为高风险
        if item_record.eval in preset_file.high_risk:
            high_risk = True
        else:
            high_risk = False

        # 确认符合状态
        if item_record.check is True:
            conform = constant.STATUS_EXCHANGE.get(
                item_record.conform, "")
        else:
            conform = ""

        # 确认整改说明
        if item_record.explain is None:
            explain = ""
        else:
            explain = item_record.explain

        res = [_eval,
               (preset_file.fixed_text[item_record.eval][1], high_risk),
               item_record.advice,
               explain,
               conform]
        if kind == "artificial":
            res.insert(3, item_record.device)
        content_data.append(res)
    return content_data


async def pdf_cmd(html: str, html_data: str) -> Tuple[str, str, str]:
    """构建生成PDF文档指令
    return cmd pdf_path filename
    """
    # 构建指令
    cmd_path = "./bin/linux/nodejs/bin/node ./bin/sfpdf "
    url = f"--url http://127.0.0.1:8000/dist/static/pdf/src/{html} "
    file_name = datetime.now().strftime("%Y%m%d%H%M%S") + r".pdf"
    pdf_path_cmd = f"--output ./pdf/{file_name} "
    html_data = re.sub(r'"', r'\\"', html_data)
    html_data = re.sub(r',', r'\\,', html_data)
    html_data = re.sub(r' ', r'\\ ', html_data)
    html = f"--htmldata {html_data} "
    cmd_wkh = "--wkhtmltopdf ./config/normal_wkhtmltopdf.config.js"
    cmd = cmd_path + url + pdf_path_cmd + html + cmd_wkh

    # 文件存放路径
    pdf_path_dir = "/sfpdf/pdf"
    if not os.path.exists(pdf_path_dir):
        os.mkdir(pdf_path_dir)
    pdf_path = os.path.join(pdf_path_dir, file_name)
    # print(cmd)
    return cmd, pdf_path, file_name
