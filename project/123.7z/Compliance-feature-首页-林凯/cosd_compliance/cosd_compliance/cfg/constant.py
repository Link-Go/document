# PDF 下载超时时长
PDF_DOWNLOAD_TIMEOUT = 60

SAFETYLEVEL = [2, 3]
SAFETY_LEVEL_EXCHANGE = {2: "二", 3: "三"}
STATUS_EXCHANGE = {1: "符合", 2: "不符合"}

# 不同类型对应的HTML页面
HTML_MAP = {
    "index": "index.html",
    "setting": "setting.html",
    "overall": "global.html",
    "artificial": "check.html"
}

# 所有的评估项
EVALUATION_ITEMS = 74

# sip_token
SIP_TOKEN = {"token": ""}
