from typing import Dict
from fastapi import WebSocket

CONNECTIONS: Dict[str, WebSocket] = {}  # websocket connections
WS_TIMEOUT = 3  # second
PING_INTERVAL = 60  # second
CRONJOB_INTERVAL = 20  # second
AUTH_URL = 'http://10.87.22.2:8000'

