# class SipURL(object):
#     """与Sip进行对接的接口"""
#     host = ""
#     # 认证
#     web_auth_api = "{}/api/compliance/web_auth".format(host)
#     # 获取业务系统列表
#     list_systems = "{}/api/compliance/systems".format(host)
#     # 获取安全设备列表
#     list_devices = "{}/api/compliance/devices".format(host)
#     # Sip客户端登录界面，用于认证不通过后进行跳转
#     client_logging = ""


# 配置指引存放路径
cfg_guide_path = './cosd_compliance/guide/cfg_guide'

# 全局分析
global_template_path = "./cosd_compliance/guide/全局分析指引.docx"
global_docx_path = "./cosd_compliance/guide/global"

# 人工核查
artificial_template_path = "./cosd_compliance/guide/人工核查指引.docx"
artificial_docx_path = "./cosd_compliance/guide/artificial"

# 生成docx所需图片
hish_risk = "./cosd_compliance/guide/高风险项.png"

# 执行生成PDF文件的路径
pdf_path = "/sfpdf"


class SipURL(object):
    """与Sip进行对接的接口"""
    host = "http://127.0.0.1:8080"
    # 认证
    web_auth_api = "{}/api/compliance/web_auth".format(host)
    # 获取业务系统列表
    list_systems = "{}/api/compliance/systems".format(host)
    # 获取安全设备列表
    list_devices = "{}/api/compliance/devices".format(host)
    # Sip客户端登录界面，用于认证不通过后进行跳转
    client_logging = "http://127.0.0.1:8000/index"
