from typing import List, Optional, Any, Dict
from ipaddress import IPv4Address
from enum import Enum

from pydantic import BaseModel

from . import enums


class SubCfgGuide(BaseModel):
    """单项配置指引"""
    device: str
    address: str
    conform: str
    question: Optional[str]
    cfg: str


class SubItemInfo(BaseModel):
    id: str
    question: str
    guide: str


class SubItemGuide(BaseModel):
    name: str
    address: IPv4Address
    conform: str
    cfg: List[SubItemInfo]


class CfgGuide(BaseModel):
    """全局配置指引"""
    system_name: str
    safety_level: int
    time: str
    results: List[SubItemGuide]


class SubOverAnalyze(BaseModel):
    """全局配置指引单项结果"""
    eval: str
    requirement: str
    advice: str
    explain: Optional[str]
    conform: int
    check: bool


class OverAnalyzeGuide(CfgGuide):
    """全局分析指引"""
    results: List[SubOverAnalyze]


class SubArtificial(SubOverAnalyze):
    """单项目人工核查指引"""
    device: str


class ArtificialGuide(CfgGuide):
    """人工核查指引"""
    results: List[SubArtificial]


class PDFKindInfor(str, Enum):
    """生成PDF文件的类型"""
    global_ = "global"
    artificial = "artificial"
    index = "index"
    setting = "setting"


class PDF(BaseModel):
    """生成PDF文件所需参数"""
    system: str
    level: str
    time: str
    title: str
    id: int


class PartReport(BaseModel):
    """报告部分数据"""
    system_list: Dict[str, List[IPv4Address]]
    device_list: Dict[str, List[Dict[enums.SafetyDevType, IPv4Address]]]
    conformities: int
    unconformities: int
    corrective: int
    incre_conformities: int
