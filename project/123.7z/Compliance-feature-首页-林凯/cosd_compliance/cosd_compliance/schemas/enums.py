from enum import Enum


class ConformStatus(int, Enum):
    """测试项状态"""
    conformity = 1
    partial_match = 2
    inconformity = 3
    unconfirm = 4
    not_apply = 5


class OS(str, Enum):
    """操作系统"""
    windows = "windows"
    linux = "linux"


class DevStaus(str, Enum):
    """设备状态"""
    online = "online"
    offline = "offline"
    unsupported = "unsupported"
    low_version = "low_version"


class SafetyLevel(int, Enum):
    """保护等级"""
    second = 2
    third = 3


class SystemDevType(str, Enum):
    """主机设备类型"""
    terminal = "终端"
    server = "服务器"


class SupportedSafetyDevType(str, Enum):
    """现在支持的设备"""
    AF = "AF"
    AC = "AC"
    SIP = "SIP"
    MIRROR = "MIRROR"
    EDR = "EDR"


class NormalSafetyDevVersion(str, Enum):
    """各产品标准版本"""
    AF = "8.0.7"
    AC = "8.0.7"
    SIP = "8.0.7"
    MIRROR = "8.0.7"
    EDR = "8.0.7"


class SafetyDevType(str, Enum):
    """设备类型"""
    AF = "AF"
    TS = "TS"
    EDR = "EDR"
    AC = "AC"
    VSS = "VSS"
    SSLVPN = "SSLVPN"
    DAS_DEV_TYPE = "DAS_DEV_TYPE"
    WAC_DEV = "WAC_DEV"
    FRTA = "FRTA"
    BBC = "BBC"
    EYE_DEV = "EYE_DEV"
    MIRROR = "MIRROR"
    STA_AD = "STA_AD"
    NETBIOS = "NETBIOS"
    BT = "BT"
    SIP = "SIP"


class SafetyDevTag(str, Enum):
    """标签类型"""
    tag_1 = "互联网出口域"
    tag_2 = "运维管理域"
    tag_3 = "核心业务域"
    tag_4 = "终端接入域"
    tag_5 = "对外服务域"
    tag_6 = "核心交换域"
    tag_7 = "外联域"
    tag_8 = "其它业务域"


class UnconformKind(str, Enum):
    """不符合项的种类"""
    global_ = "global"
    artificial = "artificial"


class Operate(str, Enum):
    """用户操作"""
    create = "create"
    update = "update"
    delete = "delete"
