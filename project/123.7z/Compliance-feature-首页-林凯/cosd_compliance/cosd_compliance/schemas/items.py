from typing import Optional

from pydantic import BaseModel

from . import enums


class CheckItem(BaseModel):
    """核查确认项目"""
    id: int
    requirements: str
    guide: str
    conform: enums.ConformStatus
    check: bool
    explain: Optional[str]


class CheckInfo(BaseModel):
    """获取单项核查确认信息"""
    id: int
    conform: int
    explain: str


class ItemUpdate(BaseModel):
    """核查确认更新"""
    conform: enums.ConformStatus  # 符合状态
    explain: str = ""
