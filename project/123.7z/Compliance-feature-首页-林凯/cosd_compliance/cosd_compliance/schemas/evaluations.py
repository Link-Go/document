from typing import List, Optional
from pydantic import BaseModel
from ipaddress import IPv4Address
from enum import Enum

from . import enums

# class TaskStatus(str, Enum):
#     """任务状态"""
#     waiting = "waiting"
#     status = "running"
#     finish = "finish"
#     cancel = "cancel"
#     fail = "fail"


class RunningStatus(str, Enum):
    status = "evaluating"


class StatusRes(BaseModel):
    id: Optional[int] = 0
    res: bool


class IP(BaseModel):
    ip: IPv4Address


class SystemDevInfo(IP):
    type: enums.SystemDevType


class SafetyDevInfo(BaseModel):
    type: enums.SafetyDevType
    tag: Optional[enums.SafetyDevTag] = None
    address: IPv4Address


class Evaluation(BaseModel):
    """评估记录"""
    id: int
    name: str
    level: enums.SafetyLevel
    system_devices: List[SystemDevInfo]
    safety_devices: List[SafetyDevInfo]
    illegality: int
    risks: int
    to_confirm: int = 0
    time: str


class System(SystemDevInfo):
    """创建任务需要的主机设备信息"""
    os: enums.OS


class SafetyDev(SafetyDevInfo):
    """创建任务需要的安全设备信息"""
    deviceid: str
    name: str
    version: str


class EvaluationCreate(BaseModel):
    """创建评估任务"""
    system_name: str
    system_list: List[System]
    devices_list: List[SafetyDev]
    level: enums.SafetyLevel
    is_net: bool
    is_vpn: bool
    is_inside: bool
    is_gateway: bool
    is_email: bool
    is_spam: bool
    is_remote: bool


class EvaluationCreateRes(BaseModel):
    """创建评估任务结果"""
    id: int
    result: bool
    detail: str


class GlobalReEvaluation(BaseModel):
    """重新开始评估"""
    id: int
    name: str


class HistoryEvaluation(EvaluationCreate):
    """历史评估记录"""
    pass


class OperationMod(BaseModel):
    """用户操作"""
    eid: Optional[int] = None
    itemid: Optional[int] = None
    operation: enums.Operate
    field: str
    old: str
    new: str


class DevicesID(BaseModel):
    """当前评估任务的安全设备ID"""
    system: str
    devices: List[str]
