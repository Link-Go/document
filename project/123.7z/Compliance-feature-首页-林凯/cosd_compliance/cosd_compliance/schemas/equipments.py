from typing import List, Optional
from pydantic import BaseModel
from ipaddress import IPv4Address

from . import enums


class SystemDevice(BaseModel):
    """主机设备"""
    ip: IPv4Address
    type: enums.SystemDevType
    status: enums.DevStaus
    os: enums.OS


class SystemList(BaseModel):
    """主机设备列表"""
    name: str
    asset: List[SystemDevice]


class DeviceList(BaseModel):
    """安全设备列表"""
    type: enums.SafetyDevType
    status: enums.DevStaus
    system: IPv4Address
    name: str
    deviceid: str
    version: str
    tag: Optional[enums.SafetyDevTag] = None


class SysDevList(BaseModel):
    """评估系统,设备列表"""
    systems: List[SystemList]
    devices: List[DeviceList]
    level: List[int]


class UpdateDevTag(BaseModel):
    """更新设备标志"""
    deviceid: str
    tag: Optional[enums.SafetyDevTag]


class DevTagMark(UpdateDevTag):
    """更新设备标志结果"""
    result: bool
    detail: str = ""
