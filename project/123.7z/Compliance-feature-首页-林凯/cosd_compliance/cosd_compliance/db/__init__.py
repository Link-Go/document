import os
import platform

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

run_path = os.path.abspath(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))))
database = os.path.join(run_path, "data")

if platform.system() == "Windows":
    SQLALCHEMY_DATABASE_URL = f"sqlite:///{database}/cosd_compliance.db"
else:
    SQLALCHEMY_DATABASE_URL = f"sqlite:////{database}/cosd_compliance.db"

# SQLALCHEMY_DATABASE_URL = "postgresql://user:password@postgresserver/db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
