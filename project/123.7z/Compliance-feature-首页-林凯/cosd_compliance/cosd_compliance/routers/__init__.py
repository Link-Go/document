# coding=utf-8

from fastapi import APIRouter
from cosd_compliance.routers.endpoints import (evaluations, guides, equipments,
                                               ws_routers, items)

api_router = APIRouter()

api_router.include_router(evaluations.router,
                          prefix="/evaluations",
                          tags=["evaluations"])
api_router.include_router(guides.router, prefix="/guides", tags=["guides"])
api_router.include_router(items.router, prefix="/items", tags=["items"])
api_router.include_router(equipments.router,
                          prefix="/equipments",
                          tags=["equipments"])
# api_router.include_router(
#     ws_routers.router, prefix="/ws", tags=["ws"])
