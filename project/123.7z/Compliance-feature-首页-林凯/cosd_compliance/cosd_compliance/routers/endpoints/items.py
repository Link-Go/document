from typing import List
from fastapi import APIRouter, status, HTTPException, Depends
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from cosd_compliance import schemas
from cosd_compliance.db import get_db
from cosd_compliance.cfg import preset_file
from cosd_compliance import crud

router = APIRouter()


@router.get("/{evaluate_id}",
            response_model=List[schemas.CheckItem],
            status_code=status.HTTP_200_OK)
async def view_evaluation_checklist(evaluate_id: int,
                                    kind: schemas.UnconformKind,
                                    db: Session = Depends(get_db)):
    """获取核查确认列表"""
    items_record = crud.items.checklist(db=db, kind=kind, id=evaluate_id)

    results = []
    for item_record in items_record:
        if item_record.check:
            conform = item_record.conform
        else:
            conform = 4

        if item_record.explain:
            explain = item_record.explain.split(":")[1].strip()
        else:
            explain = None

        results.append(schemas.CheckItem(
            id=item_record.id,
            check=item_record.check,
            requirements=preset_file.fixed_text[item_record.eval][1],
            guide=item_record.advice,
            conform=conform,
            explain=explain
        ))
    return results


@router.get("/{id}",
            response_model=schemas.CheckInfo,
            status_code=status.HTTP_200_OK)
async def view_item_explain(id: int,
                            db: Session = Depends(get_db)):
    """获取单项核查确认信息"""
    # 查询记录是否存在
    record = crud.items.get(db, id)
    if not record:
        raise HTTPException(status_code=404, detail=f"{id} not found")

    # 返回核查项的信息
    if record.check:
        conform = record.conform
    else:
        conform = 4

    if record.explain:
        explain = record.explain.split(":")[1].strip()
    else:
        explain = ""

    return schemas.CheckInfo(
        id=record.id,
        conform=conform,
        explain=explain
    )


@router.put("/{id}",
            status_code=status.HTTP_200_OK)
async def update_item_record(id: int,
                             item_update: schemas.ItemUpdate,
                             db: Session = Depends(get_db)):
    """更新核查项"""
    # 只有全局确认和人工核查的部分可以进行修改
    item = crud.items.unconform_item(db=db, id=id)
    if item is None:
        raise HTTPException(status_code=400, detail="bad request")

    # 数据判断
    explain = item_update.explain.strip()
    if not explain:
        raise HTTPException(status_code=400, detail="请输入正确的说明")

    # 更新记录
    crud.oper.create(db, schemas.OperationMod(
        itemid=item.id,
        operation="update",
        field="conform",
        old=item.conform,
        new=item_update.conform
    ))
    crud.oper.create(db, schemas.OperationMod(
        itemid=item.id,
        operation="update",
        field="explain",
        old=item.explain,
        new=item_update.explain
    ))

    crud.items.update(db, item, {"conform": item_update.conform})
    crud.items.update(db, item, {"explain": f"用户手动确认: {item_update.explain}"})

    if not item.check:
        crud.oper.create(db, schemas.OperationMod(
            itemid=item.id,
            operation="update",
            field="check",
            old=False,
            new=True
        ))
        crud.items.update(db, item, {"check": True})

    return JSONResponse(content={"result": True, "detail": "核查确认成功"})
