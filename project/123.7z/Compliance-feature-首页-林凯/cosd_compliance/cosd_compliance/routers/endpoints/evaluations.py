# coding=utf-8
import json
import uuid

from typing import List, Optional, Union
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import Response
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session

from cosd_compliance import schemas, crud
from cosd_compliance.models import Evaluations
from cosd_compliance.db import get_db
from cosd_compliance.utils import ws_utils, routers_utils
from cosd_compliance.cfg import constant
from cosd_compliance.path import path

router = APIRouter()


async def system_devs_status(systems: schemas.SystemList,
                             task_system_name: str) -> bool:
    """判断主机设备在线状况"""
    for system in systems:
        # 确定任务主机设备的状态，离线则不允许测试
        if system["name"] == task_system_name:
            for system_device in system["asset"]:
                if system_device["status"] == "offline":
                    return False
            else:
                break
    return True


async def delete_task(db: Session, record: Evaluations):
    """取消任务"""
    devices_list = set()
    devices = json.loads(record.devices)
    for device in devices:
        devices_list.add(device["address"])

    _, failed = await ws_utils.delete_task(
        task_id=f"{record.uuid}_{record.count}", devices=devices_list)

    if failed:
        raise HTTPException(status_code=422, detail="任务取消失败")

    crud.oper.create(
        db,
        schemas.OperationMod(eid=record.id,
                             operation="update",
                             field="status",
                             old=record.status,
                             new="cancel"))
    crud.eva.update(db, record, {"status": "cancel"})


async def re_create_task(record: Evaluations, max_count: int):
    """重新创建任务"""
    system_list, devices_list = set(), set()
    mirror, edr = False, False
    mirror_id, edr_id = "", ""

    devices = json.loads(record.devices)
    systems_list = json.loads(record.system)
    for system_device in systems_list:
        system_list.add(system_device["ip"])
    for device in devices:
        devices_list.add(device["address"])
        if device["type"] == schemas.SafetyDevType.MIRROR:
            mirror, mirror_id = True, device["address"]
        elif device["type"] == schemas.SafetyDevType.EDR:
            edr, edr_id = True, device["address"]

    # 判断是否有同时勾选了云镜与EDR
    if mirror and edr:
        system_list = (mirror_id, system_list)
    elif edr:
        system_list = (edr_id, system_list)
    else:
        system_list = (mirror_id, system_list)

    _, failed = await ws_utils.create_task(
        task_id=f"{record.uuid}_{max_count + 1}",
        level=record.level,
        address=system_list,
        devices=devices_list)

    if failed:
        raise HTTPException(status_code=500, detail="评估任务创建失败")


async def create_task(task: schemas.EvaluationCreate, task_uuid: str):
    """创建任务"""
    system_list, devices_list = set(), set()
    mirror, edr = False, False
    mirror_id, edr_id = "", ""

    # 数据转换
    task = jsonable_encoder(task)
    for system_device in task["system_list"]:
        system_list.add(system_device["ip"])
    for device in task["devices_list"]:
        devices_list.add(device["address"])
        if device["type"] == schemas.SafetyDevType.MIRROR:
            mirror, mirror_id = True, device["address"]
        elif device["type"] == schemas.SafetyDevType.EDR:
            edr, edr_id = True, device["address"]

    # 判断是否有同时勾选了云镜与EDR
    if mirror and edr:
        system_list = (mirror_id, system_list)
    elif edr:
        system_list = (edr_id, system_list)
    else:
        system_list = (mirror_id, system_list)

    # 发布任务，successful，failed根据是否进行展示再使用
    _, failed = await ws_utils.create_task(task_id=task_uuid + "_0",
                                           level=task["level"],
                                           address=system_list,
                                           devices=devices_list)

    if failed:
        raise HTTPException(status_code=500, detail="评估任务创建失败")


@router.get("",
            response_model=Union[List[List[schemas.Evaluation]],
                                 schemas.HistoryEvaluation, schemas.StatusRes],
            status_code=status.HTTP_200_OK)
async def evaluations(status: Optional[schemas.RunningStatus] = None,
                      name: str = None,
                      db: Session = Depends(get_db)):
    '''获取评估记录'''
    # 状态确认
    if status:
        record = crud.eva.get_running_status(db)
        if record:
            return schemas.StatusRes(id=record.id, res=True)
        else:
            return schemas.StatusRes(res=False)

    # 返回历史记录
    if name:
        return crud.eva.get_history(db, name)

    # 不存在数据返回空
    if not crud.eva.get_nums(db):
        return

    # 获取记录中的名字
    names = crud.eva.get_names(db)

    results = []
    # 构建返回的数据格式
    for name in names:
        records = crud.eva.get_records_by_name(db, name.name)
        _results = []
        for record in records:
            # system_devices = ast.literal_eval(record.system)
            # safety_devices = ast.literal_eval(record.devices)
            system_devices = json.loads(record.system)
            safety_devices = json.loads(record.devices)
            result = schemas.Evaluation(
                id=record.id,
                name=record.name,
                level=record.level,
                system_devices=system_devices,
                safety_devices=safety_devices,
                time=record.datetime.strftime("%Y-%m-%d %H:%M:%S"),
                illegality=record.illegality,
                risks=record.risks,
                to_confirm=record.configs,
            )

            for item in record.items:
                if item.kind in ["global", "artificial"] and item.conform != 1:
                    result.to_confirm += 1
            _results.append(result)
        results.append(_results)
    return results


@router.post("",
             response_model=Optional[schemas.EvaluationCreateRes],
             status_code=status.HTTP_201_CREATED)
async def create_evaluation(task: schemas.EvaluationCreate,
                            db: Session = Depends(get_db)):
    """创建评估任务"""
    status = crud.eva.get_running_status(db)
    print(status)
    if status.res:
        raise HTTPException(status_code=400, detail="当前有任务在进行，无法创建新的任务")

    # 重新获取设备状态
    token = constant.SIP_TOKEN.get("token", "")
    systems = await routers_utils.requests_list(path.SipURL.list_systems,
                                                token)
    systems = [{
        "name":
        "财务系统",
        "asset": [
            {
                "ip": "192.168.1.1",
                "type": "服务器",  # 终端、服务器
                "status": "online",  # online, offline,
                "os": "linux",  # linux, windows
            },
            {
                "ip": "192.168.1.2",
                "type": "服务器",  # 终端、服务器
                "status": "online",  # online, offline,
                "os": "linux",  # linux, windows
            }
        ]
    }]

    # 判断是否在线
    status_res = await system_devs_status(systems, task.system_name)
    if not status_res:
        raise HTTPException(status_code=400, detail="主机设备离线，请重新确认")

    task_uuid = str(uuid.uuid1())
    # 创建任务
    # await create_task(task, task_uuid)

    # 创建评估记录
    new_record = crud.eva.create_evaluation(db=db,
                                            task_uuid=task_uuid,
                                            task=task)
    return schemas.EvaluationCreateRes(id=new_record.id,
                                       result=True,
                                       detail="评估任务创建成功")


@router.post("/global",
             response_model=schemas.EvaluationCreateRes,
             status_code=status.HTTP_201_CREATED)
async def re_create_evaluation(task: schemas.GlobalReEvaluation,
                               db: Session = Depends(get_db)):
    """重新创建评估任务"""
    # 判断数据是否存在
    record = crud.eva.get(db, task.id)
    if not record:
        raise HTTPException(status_code=400, detail="bad request")

    # 判断当前是否有任务在进行
    status = crud.eva.get_running_status(db)
    if status:
        raise HTTPException(status_code=400, detail="当前有任务在进行，无法创建新的任务")

    # 获取主机设备列表
    token = constant.SIP_TOKEN.get("token", "")
    systems = await routers_utils.requests_list(path.SipURL.list_systems,
                                                token)
    systems = [{
        "name":
        "财务系统",
        "asset": [
            {
                "ip": "192.168.1.1",
                "type": "服务器",  # 终端、服务器
                "status": "online",  # online, offline,
                "os": "linux",  # linux, windows
            },
            {
                "ip": "192.168.1.2",
                "type": "服务器",  # 终端、服务器
                "status": "online",  # online, offline,
                "os": "linux",  # linux, windows
            }
        ]
    }]

    # 判断是否在线
    status_res = await system_devs_status(systems, task.name)
    if not status_res:
        raise HTTPException(status_code=400, detail="主机设备离线，请重新确认")

    # 创建任务
    max_count = crud.eva.get_max_count(db, record.uuid)
    # await re_create_task(record, max_count)

    # 创建评估记录
    new_record = crud.eva.re_create_evaluation(db, max_count, record)
    return schemas.EvaluationCreateRes(id=new_record.id,
                                       result=True,
                                       detail="重新评估任务创建成功")


@router.delete("/{id}")
async def del_evaluation_record(id: int, db: Session = Depends(get_db)):
    """删除单条记录"""
    # 判断状态 [已完成，取消] 或 [等待，测评中]
    record = crud.eva.get(db, id)
    if not record:
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    if record.status in ["waiting", "evaluating"]:
        await delete_task(db, record)

    # 逻辑删除，添加用户操作记录
    crud.oper.create(
        db,
        schemas.OperationMod(eid=record.id,
                             operation="delete",
                             field="delete",
                             old=record.delete,
                             new=True))
    crud.eva.logic_del_evaluation(db, id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/devices", response_model=schemas.DevicesID)
async def evaluating_devices(db: Session = Depends(get_db)):
    """获取当前任务的安全设备"""
    record = crud.eva.get_running_status(db)
    if not record:
        raise HTTPException(status_code=404, detail="当前没有任务在进行")
    devices = json.loads(record.devices)
    devices_id = []
    for dev in devices:
        devices_id.append(dev["deviceid"])
    return schemas.DevicesID(system=record.name, devices=devices_id)
