import logging
import asyncio
from enum import Enum
from starlette.websockets import WebSocketState
from fastapi import APIRouter, WebSocket, status

# customized
from cosd_compliance.cfg.ws_cfg import CONNECTIONS, PING_INTERVAL
from cosd_compliance.utils.ws_utils import create_task, access_auth, query_task, query_setting, delete_task

# global variables
LOCK = asyncio.Lock()

# init
router = APIRouter()
logger = logging.getLogger(__name__)


@router.websocket("/")
async def websocket_endpoint(websocket: WebSocket, token: str, device_id: str, app_version: str):
    # access auth
    # if not access_auth(token):
    #     print(f'access deny: {device_id}')
    #     await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
    #     return

    # accept
    await websocket.accept()
    CONNECTIONS[device_id] = websocket

    while True:
        await asyncio.sleep(PING_INTERVAL)
        try:
            await websocket.send_text('ping')
        except Exception as e:
            print(e)
            await websocket.close()
            if device_id in CONNECTIONS:
                CONNECTIONS.pop(device_id)
            print(CONNECTIONS)
            return


# @router.on_event("startup")
# async def on_startup():
#     # asyncio.ensure_future(auto_reconnect())
    # In Python 3.7+
    # asyncio.create_task(auto_reconnect())


async def auto_reconnect():
    while True:
        # TODO: complete reconnect
        await asyncio.sleep(10)
        print('cronjob start')

        # TODO: for test, rm after
        # query setting
        print('<--- begin test query setting')
        query_result = await query_setting('device-1', '1', 1)
        print(
            f'result. successful:{query_result.successful}, messge:{query_result.message}')
        print('test query setting finished --->')

        # create task
        print('<--- begin test create task')
        successful, failed = await create_task('task_id', 2, set(), set(['device-1']))
        print(f'successful result :{successful}\nfailed result:{failed}')
        print('test create task finished --->')

        # query task
        print('<--- begin test query task')
        successful, failed = await query_task('task_id', set(['device-1']))
        print(f'successful result :{successful}\nfailed result:{failed}')
        print('test query task finished --->')

        # delete task
        print('<--- begin test delete task')
        successful, failed = await delete_task('task_id', set(['device-1']))
        print(f'successful result :{successful}\nfailed result:{failed}')
        print('test delete task finished --->')

        print('cronjob finished')
