# coding=utf-8
import ast
import json
import subprocess
import time
import os
import asyncio

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import ValidationError

from cosd_compliance import schemas
from cosd_compliance.models import Items, Evaluations
from cosd_compliance.db import get_db
from cosd_compliance.cfg import preset_file, constant
from cosd_compliance.path import path
from cosd_compliance.utils import routers_utils
from cosd_compliance import crud


router = APIRouter()


async def unconform_nums(db: Session, record: Evaluations):
    """获取待处理总数"""
    num = 0
    for _kind in schemas.UnconformKind:
        num += crud.items.unconform_items_num(db, record.id, _kind)
    num += record.configs
    return num


@router.get("/config/{item_id}/{item_eval}",
            response_model=schemas.SubCfgGuide,
            status_code=status.HTTP_200_OK)
async def view_cfg_guide(item_id: int, item_eval: str,
                         db: Session = Depends(get_db)):
    """获取单项配置指引"""
    record = crud.items.config_item(db, item_id)
    if not record:
        raise HTTPException(status_code=400, detail="bad request")

    device = record.device
    address = record.address
    # 安全要求详情
    conform = preset_file.fixed_text[record.eval][1]
    # 主要问题
    subitems = ast.literal_eval(record.subitems)
    # subitems = json.loads(record.subitems)
    question = [_item["message"]
                for _item in subitems if _item["id"] == item_eval]

    # 获取整改指引
    cfg = await routers_utils.cfg_guide(record.device, record.deviceid, item_eval)
    return schemas.SubCfgGuide(device=device,
                               address=address,
                               conform=conform,
                               question=question[0] if question else None,
                               cfg=cfg)


@router.get("/config/{evaluate_id}",
            response_model=schemas.CfgGuide,
            status_code=status.HTTP_200_OK)
async def view_cfg_guides(evaluate_id: int,
                          db: Session = Depends(get_db)):
    """获取全局配置指引"""
    record = crud.eva.get(db, evaluate_id)
    if not record:
        raise HTTPException(status_code=400, detail="bad request")

    items_record = crud.items.config_items(db, evaluate_id)
    results = []
    for item_record in items_record:
        subitems = ast.literal_eval(item_record.subitems)
        subitems_info = []

        for _subitems in subitems:
            subitems_info.append({
                "id": _subitems["id"],
                "question": _subitems["message"],
                "guide": await routers_utils.cfg_guide(item_record.device,
                                                       item_record.deviceid,
                                                       item_record.eval + "-" + _subitems["id"])
            })
        conform = preset_file.fixed_text[item_record.eval][1]
        results.append({
            "name": item_record.device,
            "address": item_record.address,
            "conform": conform,
            "cfg": subitems_info
        })

    return schemas.CfgGuide(system_name=record.name,
                            safety_level=record.level,
                            time=record.datetime.strftime(
                                "%Y-%m-%d %H:%M:%S"),
                            results=results)


@router.get("/global/{evaluate_id}",
            response_model=schemas.OverAnalyzeGuide,
            status_code=status.HTTP_200_OK)
async def view_global_guide(evaluate_id: int,
                            db: Session = Depends(get_db)):
    """全局分析指引"""
    record = crud.eva.get(db, evaluate_id)
    # 记录是否存在
    if not record:
        raise HTTPException(status_code=400, detail="bad request")

    items_record = crud.items.unconform_items(db, evaluate_id, "global")
    # 错误类型是否存在
    if not items_record:
        raise HTTPException(status_code=400, detail="bad request")

    # 构建数据格式
    results = []
    for item_record in items_record:
        results.append({
            "eval": preset_file.fixed_text[item_record.eval][0],
            "requirement": preset_file.fixed_text[item_record.eval][1],
            "advice": item_record.advice,
            "explain": item_record.explain,
            "conform": item_record.conform,
            "check": item_record.check
        })

    return schemas.OverAnalyzeGuide(system_name=record.name,
                                    safety_level=record.level,
                                    time=record.datetime.strftime(
                                        "%Y-%m-%d %H:%M:%S"),
                                    results=results)


@router.get("/artificial/{evaluate_id}",
            response_model=schemas.ArtificialGuide,
            status_code=status.HTTP_200_OK)
async def view_artificial_guide(evaluate_id: int,
                                db: Session = Depends(get_db)):
    """人工核查指引"""
    record = crud.eva.get(db, evaluate_id)
    # 记录是否存在
    if not record:
        raise HTTPException(status_code=400, detail="bad request")

    items_record = crud.items.unconform_items(db, evaluate_id, "artificial")
    # 错误类型是否存在
    if not items_record:
        raise HTTPException(status_code=400, detail="bad request")

    # 构建数据格式
    results = []
    for item_record in items_record:
        _eval = preset_file.fixed_text[item_record.eval][0]
        kind = preset_file.safety_kind[item_record.eval[0]]
        results.append({
            "eval": kind + "-" + _eval,
            "requirement": preset_file.fixed_text[item_record.eval][1],
            "advice": item_record.advice,
            "device": item_record.device,
            "explain": item_record.explain,
            "conform": item_record.conform,
            "check": item_record.check
        })

    return schemas.ArtificialGuide(system_name=record.name,
                                   safety_level=record.level,
                                   time=record.datetime.strftime(
                                       "%Y-%m-%d %H:%M:%S"),
                                   results=results)


@router.get("/docx/{evaluate_id}")
async def download_guide(
        evaluate_id: int,
        kind: schemas.UnconformKind,
        db: Session = Depends(get_db)):
    """docx指引下载"""
    cover_data = await routers_utils.deal_cover_data(evaluate_id, db)
    content_data = await routers_utils.deal_content_data(evaluate_id, kind, db)
    file_name, file_path = await routers_utils.\
        download_path(kind, cover_data, content_data)
    return FileResponse(file_path, filename=file_name)


@router.get("/pdf/{evaluate_id}")
async def download_pdf(evaluate_id: int,
                       kind: schemas.PDFKindInfor,
                       htmldata: str):
    """pdf文件下载"""
    # print(html_data)
    html_data_dict = ast.literal_eval(htmldata)
    try:
        schemas.PDF(**html_data_dict)
    except ValidationError:
        raise HTTPException(status_code=400, detail="bad request")
    html = constant.HTML_MAP[kind]
    htmldata = json.dumps(html_data_dict)
    cmd, pdf_path, file_name = await routers_utils.pdf_cmd(html, htmldata)

    # 子进程执行
    start_time = time.time()
    end_time = start_time + constant.PDF_DOWNLOAD_TIMEOUT
    subprocess.Popen(cmd, cwd=path.pdf_path, shell=True,
                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # 设置超时时长
    while end_time > time.time():
        if not os.path.exists(pdf_path):
            await asyncio.sleep(1)
        else:
            break
    if not os.path.exists(pdf_path):
        raise HTTPException(status_code=500, detail="PDF文件生成失败，请稍后重试")
    return FileResponse(pdf_path, filename=file_name)


@router.get("/report/{evaluate_id}",
            response_model=schemas.PartReport)
async def evaluation_report(evaluate_id: int,
                            db: Session = Depends(get_db)):
    """评估报告"""
    record = crud.eva.get(db, evaluate_id)
    system_list = json.loads(record.system)
    device_list = json.loads(record.devices)
    report_system_list, report_device_list = {}, {}
    for system_dev in system_list:
        t = system_dev["type"]
        r = report_system_list.get(t, None)
        if not r:
            report_system_list[t] = []
        report_system_list[t].append(system_dev["ip"])

    for dev in device_list:
        t = dev.get("tag", None)
        if t is None:
            t = "未确认"
        r = report_device_list.get(t, None)
        if not r:
            report_device_list[t] = []
        report_device_list[t].append({dev["type"]: dev["address"]})
    # print(report_system_list, report_device_list)
    # 获取第一次评估的记录
    first_record = crud.eva.get_n_record(db, record.uuid, 0)

    # 合格项，不合格项，增加的合格项
    conformities = record.conform
    unconformities = constant.EVALUATION_ITEMS - conformities
    incre_conformities = record.conform - first_record.conform

    # 第一次评估需要整改的数量
    first_record_num = await unconform_nums(db, first_record)
    print(first_record_num)
    # 最新一次评估需要整改的数量
    last_record_num = await unconform_nums(db, record)
    print(last_record_num)
    # 整改的数量
    corrective = first_record_num - last_record_num
    return schemas.PartReport(system_list=report_system_list,
                              device_list=report_device_list,
                              conformities=conformities,
                              unconformities=unconformities,
                              corrective=corrective,
                              incre_conformities=incre_conformities)
