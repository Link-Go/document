import re
from typing import List

from fastapi import APIRouter, status, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import ValidationError

from cosd_compliance.models import DevicesTag
from cosd_compliance import schemas
from cosd_compliance.utils import routers_utils
from cosd_compliance.cfg import constant
from cosd_compliance.db import get_db
from cosd_compliance import crud

router = APIRouter()


async def version_judge(type_: str, version: str) -> bool:
    """版本判断"""
    normal_version = getattr(schemas.NormalSafetyDevVersion, type_, None)
    if not normal_version:
        return False

    # TODO 不同产品线的版本判断
    return True


@router.get("",
            response_model=schemas.SysDevList,
            status_code=status.HTTP_200_OK)
async def list_systems_devices(db: Session = Depends(get_db)):
    """获取业务系统与设备列表"""
    print("啦啦啦啦:", constant.SIP_TOKEN["token"])
    outer = await routers_utils.list_devices_systems(
        token=constant.SIP_TOKEN.get("token", ""))
    system = [{
        "name":
        "财务系统",
        "asset": [
            {
                "ip": "192.168.1.1",
                "type": "服务器",  # 终端、服务器
                "status": "online",  # online, offline,
                "os": "linux",  # linux, windows
            },
            {
                "ip": "192.168.1.2",
                "type": "服务器",  # 终端、服务器
                "status": "online",  # online, offline,
                "os": "linux",  # linux, windows
            }
        ]
    }]

    devices = [
        {
            "type": "AF",  # 设备类型
            "status": "online",  # 设备状态
            "system": "192.168.1.1",
            "name": "出口防火墙",
            "deviceid": "ABCDEFG",
            "version": "AF 8.0.7"
        },
        {
            "type": "AC",  # 设备类型
            "status": "offline",  # 备设状态
            "system": "192.168.1.2",
            "name": "出口防火墙",
            "deviceid": "ABCDEFH",
            "version": "AC 8.0.7"
        },
        {
            "type": "AF",  # 设备类型
            "status": "online",  # 设备状态
            "system": "192.168.1.3",
            "name": "出口防火墙",
            "deviceid": "ABCDFGH",
            "version": "AF 8.0.7"
        },
        {
            "type": "BBC",  # 设备类型
            "status": "offline",  # 备设状态
            "system": "192.168.1.4",
            "name": "出口防火墙",
            "deviceid": "ABCEFGH",
            "version": "AC 8.0.7"
        }
    ]
    outer = [system, devices]
    if not all(outer):
        raise HTTPException(status_code=400, detail="bad request")

    # 状态变换
    for dev in outer[1]:
        try:
            if dev["type"] not in schemas.SupportedSafetyDevType.__members__:
                dev["status"] = schemas.DevStaus.unsupported
            else:
                version_judge_res = await version_judge(
                    dev["type"], dev["version"])
                if not version_judge_res:
                    dev["status"] = schemas.DevStaus.low_version
        except ValidationError:
            raise HTTPException(status_code=400, detail="bad request")

    print(outer[1])
    devices_id = [device["deviceid"] for device in outer[1]]
    devices_record = db.query(DevicesTag.device_id).\
        filter(DevicesTag.device_id.in_(devices_id)).all()
    devices_include = [
        device_record.device_id for device_record in devices_record
    ]
    devices_exclude = list(set(devices_id) ^ set(devices_include))

    # 如果设备ID存在，则更新
    for device in outer[1]:
        if device["deviceid"] in devices_include:
            tag = crud.tag.get(db, device["deviceid"])
            crud.tag.update(
                db, tag, {
                    "version": device["version"],
                    "address": device["system"],
                    "name": device["name"],
                    "type": device["type"],
                    "status": device["status"]
                })

    # 不存在则添加
    if devices_exclude:
        add_list = []
        for device in outer[1]:
            if device["deviceid"] in devices_exclude:
                add_list.append(
                    DevicesTag(device_id=device["deviceid"],
                               version=device["version"],
                               address=device["system"],
                               name=device["name"],
                               type=device["type"],
                               status=device["status"]))
        db.add_all(add_list)
    db.commit()
    last_devices = db.query(DevicesTag).\
        filter(DevicesTag.device_id.in_(devices_id)).all()

    devices = [
        schemas.DeviceList(type=device.type,
                           deviceid=device.device_id,
                           version=device.version,
                           system=device.address,
                           name=device.name,
                           tag=device.tag,
                           status=device.status) for device in last_devices
    ]

    results = schemas.SysDevList(systems=outer[0],
                                 devices=devices,
                                 level=constant.SAFETYLEVEL)
    return results


@router.put("/devicestag",
            response_model=List[schemas.DevTagMark],
            status_code=status.HTTP_200_OK)
async def update_devices_tag(devices: List[schemas.UpdateDevTag],
                             db: Session = Depends(get_db)):
    """设备标志记录"""
    results = []
    for device in devices:
        res_deviceid = re.match(r"[a-zA-Z0-9_-]+", device.deviceid)
        res_tag = re.match(r"\w+", device.tag)
        if (not res_deviceid) or (not res_tag):
            raise HTTPException(status_code=400, detail="bad request")

        if (len(res_deviceid.group()) != len(device.deviceid)) or (len(
                res_tag.group()) != len(device.tag)):
            raise HTTPException(status_code=400, detail="bad request")

        db.query(DevicesTag).\
            filter(DevicesTag.device_id == res_deviceid.group()).\
            update({"tag": res_tag.group()})

        tag = crud.tag.get(db, res_deviceid.group())
        obj_out = crud.tag.update(db, tag, {"tag": res_tag.group()})
        results.append(
            schemas.DevTagMark(deviceid=obj_out.device_id,
                               result=True,
                               tag=obj_out.tag))
    return results
