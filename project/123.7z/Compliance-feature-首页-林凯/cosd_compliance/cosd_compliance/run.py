#!/usr/bin/env python<3.6.8>
# coding=utf-8

import requests
import re
import os

from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from cosd_compliance import models
from cosd_compliance.db import engine
from cosd_compliance import routers
from cosd_compliance.path import path
from cosd_compliance.cfg import constant

run_path = os.path.abspath(os.path.dirname(os.path.abspath(__file__)))

app = FastAPI()

models.Base.metadata.create_all(engine)

# app.mount("/static",
#           StaticFiles(directory=os.path.join(run_path, "static")),
#           name="static")

# app.mount("/3parts",
#           StaticFiles(directory=os.path.join(run_path, "ui", "3parts")),
#           name="3parts")
# app.mount("/static",
#           StaticFiles(directory=os.path.join(run_path, "ui", "static")),
#           name="static")

app.include_router(routers.api_router, prefix="/compliance")


@app.get("/index")
async def index():
    with open(os.path.join(run_path, "ui", "_index.html"), "r") as f:
        content = f.read()
    return HTMLResponse(content=content)


# @app.middleware("http")
# async def web_auth(request: Request, call_next):
#     token = request.query_params.get("token", None)
#     if not token:
#         return RedirectResponse(path.SipURL.client_logging)

#     res = re.match(r"[0-9a-zA-Z_-]{32}", token)
#     if not res:
#         return RedirectResponse(path.SipURL.client_logging)

#     url = "{}/?token={}".format(path.SipURL.web_auth_api, res.group())
#     try:
#         resp = requests.get(url, verify=False)
#     except requests.exceptions.Timeout:
#         return RedirectResponse(path.SipURL.client_logging)

#     if resp.status_code != 200:
#         return RedirectResponse(path.SipURL.client_logging)

#     if not resp.json().get("result", ""):
#         return RedirectResponse(path.SipURL.client_logging)

#     response = await call_next(request)
#     return response


@app.middleware("http")
async def get_token(request: Request, call_next):
    """获取sip_token"""
    url_path = request.url.path
    if url_path.startswith("/compliance") or url_path.startswith("/index"):
        print("开始认证一下~")
        token = request.query_params.get("token", None)
        # global sip_token
        # if token:
        #     sip_token.value = token
        if token:
            constant.SIP_TOKEN["token"] = token
    response = await call_next(request)
    return response
