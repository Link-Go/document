from enum import Enum
from typing import List
import json
from pydantic import BaseModel, Field


class WsObj(str, Enum):
    task = 'task'
    setting = 'setting'


class WsAction(str, Enum):
    create = 'create'
    query = 'query'
    delete = 'delete'


class WsMsg(BaseModel):
    obj: WsObj
    action: WsAction
    data: dict


class SettingForQuery(BaseModel):
    eval_id: str
    item_id: int


class TaskForCreate(BaseModel):
    task_id: str
    level: int
    address: List[str]
    evals: List[str] = []


class TaskForQuery(BaseModel):
    task_id: str


class TaskForDelete(BaseModel):
    task_id: str


class DeviceExeMsg(str, Enum):
    offline = 'offline'
    timeout = 'timeout'
    json_decode_error = 'internal json error'
    internal_error = 'internal error'
    success = 'success'


class DeviceExeResult(BaseModel):
    device_id: str
    successful: bool = False
    message: str = ''


class DeviceTaskItem(BaseModel):
    id: str = ''
    result: int = 0
    message: str = ''
    suggest: str = ''


class DeviceTaskRecord(BaseModel):
    id: str = ''
    result: int = 0
    items: List[DeviceTaskItem] = []


class DeviceTaskResult(BaseModel):
    name: str = ''
    total_num: int = 0
    processed_num: int = 0
    message: str = ''
    records: List[DeviceTaskRecord] = []


class DeviceDetectResult(BaseModel):
    status: str = ''
    results: List[DeviceTaskResult] = []


class DeviceQueryTaskResult(DeviceExeResult):
    """设备查询任务的结果"""
    detect_result: DeviceDetectResult = None

class DeviceQuerySettingResult(DeviceExeResult):
    bytes_data: bytes = None

