from cosd_compliance.crud.base import CRUDBase
from cosd_compliance.models import Operation


class CRUDOperation(CRUDBase[Operation]):
    pass


oper = CRUDOperation(Operation)
