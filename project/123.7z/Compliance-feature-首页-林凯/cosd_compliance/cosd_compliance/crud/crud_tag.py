from typing import Any

from sqlalchemy.orm import Session

from cosd_compliance.crud.base import CRUDBase
from cosd_compliance.models import DevicesTag


class CRUDDevicesTag(CRUDBase[DevicesTag]):
    def get(self, db: Session, id: Any) -> DevicesTag:
        return db.query(self.model).filter(self.model.device_id == id).first()


tag = CRUDDevicesTag(DevicesTag)
