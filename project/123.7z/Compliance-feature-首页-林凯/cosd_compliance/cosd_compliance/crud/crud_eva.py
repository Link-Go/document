import json

from typing import Optional
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session
from sqlalchemy import and_
from fastapi import HTTPException

from cosd_compliance.crud.base import CRUDBase
from cosd_compliance.models import Evaluations, SystemInfor, Items
from cosd_compliance import schemas
from cosd_compliance.cfg import preset_file


class CRUDEvaluations(CRUDBase[Evaluations]):
    def get_running_status(self, db: Session) -> Optional[Evaluations]:
        """获取当前是否有任务在进行"""
        return db.query(self.model).\
            filter(self.model.status.in_(
                ["waiting", "evaluating"])).one_or_none()

    def get_history(
            self, db: Session, name: str) -> schemas.HistoryEvaluation:
        """历史记录"""
        record = db.query(self.model).filter(self.model.name == name).\
            order_by(Evaluations.id.desc()).first()
        if not record:
            raise HTTPException(status_code=400, detail="bad request")

        system_infor = record.system_infor[0]
        return schemas.HistoryEvaluation(
            system_name=record.name,
            system_list=json.loads(record.system),
            devices_list=json.loads(record.devices),
            level=record.level,
            is_net=system_infor.is_net,
            is_vpn=system_infor.is_vpn,
            is_inside=system_infor.is_inside,
            is_gateway=system_infor.is_gateway,
            is_email=system_infor.is_email,
            is_spam=system_infor.is_spam,
            is_remote=system_infor.is_remote,
        )

    def get_nums(self, db: Session) -> int:
        """获取数据数量"""
        return db.query(self.model).\
            filter(and_(self.model.delete == False,
                        self.model.status == "finished")).count()

    def get_names(self, db: Session) -> Evaluations:
        """返回数据的类别"""
        return db.query(self.model.name).\
            group_by(self.model.name).order_by(self.model.id.desc()).all()

    def get_records_by_name(self, db: Session, name: str) -> Evaluations:
        """通过名称获取评估记录"""
        return db.query(self.model).filter(
            and_(self.model.name == name,
                 self.model.status == "finished",
                 self.model.delete == False)).\
            order_by(self.model.id.desc()).all()

    def create_evaluation(self,
                          db: Session,
                          task_uuid: str,
                          task: schemas.EvaluationCreate) -> Evaluations:
        """创建评估记录"""
        task = jsonable_encoder(task)
        record = self.model(uuid=task_uuid,
                            name=task["system_name"],
                            level=task["level"],
                            devices=json.dumps(task["devices_list"]),
                            system=json.dumps(task["system_list"]))
        # 业务情况
        record.system_infor = [
            SystemInfor(is_net=task["is_net"],
                        is_vpn=task["is_vpn"],
                        is_inside=task["is_inside"],
                        is_gateway=task["is_gateway"],
                        is_email=task["is_email"],
                        is_spam=task["is_spam"],
                        is_remote=task["is_remote"])
        ]
        # 需要填涂的数据项目
        record.items = [
            Items(eval=_eval) for _eval in preset_file.all_list
        ]

        db.add(record)
        db.commit()
        db.refresh(record)
        return record

    def re_create_evaluation(
            self, db: Session, count: int,
            record: Evaluations) -> Evaluations:
        new_record = Evaluations(uuid=record.uuid,
                                 count=count + 1,
                                 name=record.name,
                                 level=record.level,
                                 devices=record.devices,
                                 system=record.system)
        new_record.system_infor = [
            SystemInfor(is_net=record.system_infor[0].is_net,
                        is_remote=record.system_infor[0].is_remote,
                        is_spam=record.system_infor[0].is_spam,
                        is_gateway=record.system_infor[0].is_gateway,
                        is_vpn=record.system_infor[0].is_vpn,
                        is_inside=record.system_infor[0].is_inside,
                        is_email=record.system_infor[0].is_email)
        ]
        db.add(new_record)
        db.commit()
        db.refresh(new_record)
        return new_record

    def get_max_count(self, db: Session, uuid: str) -> int:
        """获取任务执行的次数"""
        return db.query(self.model.count).\
            filter(self.model.uuid == uuid).order_by(
                self.model.id.desc()).first()[0]

    def logic_del_evaluation(self, db: Session, id: int):
        record = self.get(db, id)
        record.delete = True
        db.commit()
        db.refresh(record)

    def get_n_record(self, db: Session, uuid: str, count: int) -> Evaluations:
        """获取第N次评估的数据"""
        return db.query(self.model).\
            filter(and_(self.model.uuid == uuid,
                        self.model.count == count)).one_or_none()


eva = CRUDEvaluations(Evaluations)
