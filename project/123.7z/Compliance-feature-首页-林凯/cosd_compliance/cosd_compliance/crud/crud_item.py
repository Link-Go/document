from typing import List

from sqlalchemy.orm import Session
from sqlalchemy import and_

from cosd_compliance.crud.base import CRUDBase
from cosd_compliance.models import Items
from cosd_compliance import schemas


class CRUDitems(CRUDBase[Items]):
    def checklist(self,
                  db: Session,
                  kind: schemas.UnconformKind,
                  id: int) -> List[Items]:
        """获取核查列表"""
        return db.query(self.model).\
            filter(and_(self.model.kind == kind,
                        self.model.pid == id)).all()

    def unconform_item(self, db: Session, id: int) -> Items:
        """获取单项核查项"""
        return db.query(self.model).filter(
            and_(self.model.id == id,
                 self.model.kind.in_(["global", "artificial"]))
        ).one_or_none()

    def unconform_items(self,
                        db: Session,
                        evaluate_id: int,
                        kind: schemas.UnconformKind) -> List[Items]:
        """获取某一类的所有不合格项"""
        return db.query(self.model).filter(
            and_(self.model.kind == kind,
                 self.model.pid == evaluate_id)
        ).all()

    def unconform_items_num(self,
                            db: Session,
                            evaluate_id: int,
                            kind: schemas.UnconformKind) -> int:
        """获取某一类的所有不合格项的数量"""
        return db.query(self.model).filter(
            and_(self.model.kind == kind,
                 self.model.pid == evaluate_id,
                 self.model.conform != 1)
        ).count()

    def config_item(self, db: Session, id: int) -> Items:
        """获取单项配置指引"""
        return db.query(self.model).filter(
            and_(self.model.id == id,
                 self.model.kind == "config")
        ).one_or_none()

    def config_items(self, db: Session, id: int) -> List[Items]:
        """获取全局配置指引"""
        return db.query(self.model).filter(
            and_(self.model.pid == id,
                 self.model.kind == "config",
                 self.model.conform.in_([2, 3, 4]))
        ).all()


items = CRUDitems(Items)
