# coding=utf-8

from fastapi.testclient import TestClient

from cosd_compliance.run import app

client = TestClient(app)


def test_view_evaluation():
    response = client.get("/compliance/evaluations")
    assert response.status_code == 200
