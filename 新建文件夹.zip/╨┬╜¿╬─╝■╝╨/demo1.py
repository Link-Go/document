import lxml
import os

from docx import Document

# 设置待自动更新目录的文件
file_name = "test.docx"

# 读取文件，初始化为document对象
word_obj = Document(os.path.realpath(file_name))

# 初始化各项参数
name_space = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
update_name_space = "%supdateFields" % name_space
val_name_space = "%sval" % name_space

# 自动更新目录
try:
    element_update_field_obj = lxml.etree.SubElement(word_obj.settings.element,
                                                     update_name_space)
    element_update_field_obj.set(val_name_space, "true")
except Exception as e:
    del e

# 保存更新后的word文件对象
word_obj.save(os.path.realpath(file_name))
