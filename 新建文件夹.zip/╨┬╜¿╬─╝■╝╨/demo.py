from docx import Document

from docx.oxml.shared import OxmlElement, qn

# from docx import Document

d = Document('demo.docx')

paragraph = d.add_paragraph()
run = paragraph.add_run()
fldChar = OxmlElement('w:fldChar')  # creates a new element
fldChar.set(qn('w:fldCharType'), 'begin')  # sets attribute on element
fldChar.text = 'foobar'  # not needed for this element, but this is how you set the text it contains
r_element = run._r
r_element.append(fldChar)  # adds new element as last child
p_element = paragraph._p
print(p_element.xml)  # shows XML so you can track your progress

# paragraph = d.add_paragraph()
# run = paragraph.add_run()
# fldChar = OxmlElement('w:fldChar')  # creates a new element
# fldChar.set(qn('w:fldCharType'), 'begin')  # sets attribute on element
# instrText = OxmlElement('w:instrText')
# instrText.set(qn('xml:space'), 'preserve')  # sets attribute on element
# instrText.text = r'TOC \o "1-3" \h \z \u'  # change 1-3 depending on heading levels you need

# fldChar2 = OxmlElement('w:fldChar')
# fldChar2.set(qn('w:fldCharType'), 'separate')
# fldChar3 = OxmlElement('w:t')
# fldChar3.text = "Right-click to update field."
# fldChar2.append(fldChar3)

# fldChar4 = OxmlElement('w:fldChar')
# fldChar4.set(qn('w:fldCharType'), 'end')

# r_element = run._r
# r_element.append(fldChar)
# r_element.append(instrText)
# r_element.append(fldChar2)
# r_element.append(fldChar4)
# p_element = paragraph._p  # can track your progress

d.save("test.docx")
